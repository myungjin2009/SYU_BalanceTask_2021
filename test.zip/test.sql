-- --------------------------------------------------------
-- 호스트:                          127.0.0.1
-- 서버 버전:                        8.0.23 - MySQL Community Server - GPL
-- 서버 OS:                        Win64
-- HeidiSQL 버전:                  11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- test 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `test` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `test`;

-- 테이블 test.app 구조 내보내기
CREATE TABLE IF NOT EXISTS `app` (
  `test_no` int NOT NULL AUTO_INCREMENT,
  `user` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `evaluation` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `point` int DEFAULT '0',
  PRIMARY KEY (`test_no`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 test.aram 구조 내보내기
CREATE TABLE IF NOT EXISTS `aram` (
  `aram_no` int NOT NULL AUTO_INCREMENT,
  `senduser` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `receiveuser` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `group_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `sendtime` datetime DEFAULT NULL,
  `content` tinyint DEFAULT NULL,
  `notsend` tinyint DEFAULT NULL,
  `point` int DEFAULT NULL,
  `msg` varchar(750) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`aram_no`) USING BTREE,
  KEY `FK_aram_user` (`senduser`) USING BTREE,
  CONSTRAINT `FK_aram_user` FOREIGN KEY (`senduser`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 test.chat 구조 내보내기
CREATE TABLE IF NOT EXISTS `chat` (
  `chat_no` int NOT NULL AUTO_INCREMENT,
  `chat_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `group_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `chat_date` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `msg` varchar(750) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `chat_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`chat_no`),
  KEY `group_name` (`group_name`),
  CONSTRAINT `FK_chat_groups` FOREIGN KEY (`group_name`) REFERENCES `groups` (`group_name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 test.friends 구조 내보내기
CREATE TABLE IF NOT EXISTS `friends` (
  `user` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '11',
  `friends` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '11',
  PRIMARY KEY (`user`,`friends`) USING BTREE,
  KEY `FK_friends_user_2` (`friends`) USING BTREE,
  CONSTRAINT `FK_friends_user` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_friends_user_2` FOREIGN KEY (`friends`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 test.groupboard 구조 내보내기
CREATE TABLE IF NOT EXISTS `groupboard` (
  `board_number` int NOT NULL,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `image` varchar(8192) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `file` varchar(8192) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `text` varchar(3000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `info_user` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `info_groupname` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '11',
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`board_number`,`info_groupname`) USING BTREE,
  KEY `FK_groupboard_user` (`info_user`) USING BTREE,
  KEY `FK_groupboard_groups` (`info_groupname`) USING BTREE,
  CONSTRAINT `FK_groupboard_groups` FOREIGN KEY (`info_groupname`) REFERENCES `groups` (`group_name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_groupboard_user` FOREIGN KEY (`info_user`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 test.groupcalendar 구조 내보내기
CREATE TABLE IF NOT EXISTS `groupcalendar` (
  `process` int NOT NULL DEFAULT '1',
  `group_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '11',
  `start` varchar(50) CHARACTER SET armscii8 COLLATE armscii8_bin DEFAULT NULL,
  `do_text` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `writer` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `end` varchar(50) CHARACTER SET armscii8 COLLATE armscii8_bin DEFAULT NULL,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`process`,`group_name`) USING BTREE,
  KEY `FK_groupcalendar_groups` (`group_name`) USING BTREE,
  KEY `FK_groupcalendar_user` (`writer`) USING BTREE,
  CONSTRAINT `FK_groupcalendar_groups` FOREIGN KEY (`group_name`) REFERENCES `groups` (`group_name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_groupcalendar_user` FOREIGN KEY (`writer`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 test.groupnotice 구조 내보내기
CREATE TABLE IF NOT EXISTS `groupnotice` (
  `board_number` int NOT NULL,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `image` varchar(8192) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `file` varchar(8192) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `text` varchar(3000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `info_user` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `info_groupname` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '11',
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`board_number`,`info_groupname`) USING BTREE,
  KEY `FK_groupboard_user` (`info_user`) USING BTREE,
  KEY `FK_groupboard_groups` (`info_groupname`) USING BTREE,
  CONSTRAINT `groupnotice_ibfk_1` FOREIGN KEY (`info_groupname`) REFERENCES `groups` (`group_name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `groupnotice_ibfk_2` FOREIGN KEY (`info_user`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin ROW_FORMAT=DYNAMIC;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 test.groups 구조 내보내기
CREATE TABLE IF NOT EXISTS `groups` (
  `group_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '11',
  `group_images` varchar(8192) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `startdate` datetime DEFAULT NULL,
  `percentage` float(4,3) DEFAULT NULL,
  `group_chatting` varchar(256) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `group_calendar` varchar(256) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `user` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '11',
  `enjoy` blob,
  `host` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '11',
  `manager` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `complete` blob,
  `category` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `host_images` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `deadline` datetime DEFAULT NULL,
  `makedate` datetime DEFAULT NULL,
  `group_no` int NOT NULL DEFAULT '0',
  `highlight` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`user`,`group_no`) USING BTREE,
  UNIQUE KEY `group_no` (`group_no`),
  UNIQUE KEY `group_name` (`group_name`),
  KEY `FK_groups_user` (`user`) USING BTREE,
  CONSTRAINT `FK_groups_user` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 test.groupusers 구조 내보내기
CREATE TABLE IF NOT EXISTS `groupusers` (
  `group_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '11',
  `user` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '11',
  `enjoy` blob,
  `leader` blob,
  `group_no` int NOT NULL,
  PRIMARY KEY (`group_name`,`user`,`group_no`) USING BTREE,
  KEY `FK_groupusers_user` (`user`) USING BTREE,
  KEY `FK_groupusers_groups_2` (`group_no`) USING BTREE,
  CONSTRAINT `FK_groupusers_groups` FOREIGN KEY (`group_name`) REFERENCES `groups` (`group_name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_groupusers_groups_2` FOREIGN KEY (`group_no`) REFERENCES `groups` (`group_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_groupusers_user` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 test.member_app 구조 내보내기
CREATE TABLE IF NOT EXISTS `member_app` (
  `member_no` int NOT NULL AUTO_INCREMENT,
  `evaluated_user` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `point` int DEFAULT NULL,
  `group_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `rater` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `evaluation` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `rater_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 test.user 구조 내보내기
CREATE TABLE IF NOT EXISTS `user` (
  `id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '11',
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '11',
  `password` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `evaluation_score` int DEFAULT NULL,
  `agreement` blob NOT NULL,
  `evaluation_text` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `clear_group` int DEFAULT NULL,
  `user_image` varchar(750) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `introduce` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `user_category` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `jwt` varchar(750) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 test.vote 구조 내보내기
CREATE TABLE IF NOT EXISTS `vote` (
  `vote_no` int NOT NULL AUTO_INCREMENT,
  `board_number` int NOT NULL,
  `discuss` int DEFAULT NULL,
  `user` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '11',
  `group_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '11',
  `group_no` int DEFAULT NULL,
  PRIMARY KEY (`vote_no`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- 내보낼 데이터가 선택되어 있지 않습니다.

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
